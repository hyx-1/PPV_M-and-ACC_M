import numpy as np
import matplotlib.pyplot as plt

Precision_Biogrid_Adappi =0.5071
Recall_Biogrid_Adappi =0.4181
F1_Biogrid_Adappi =0.4583
Acc_M_Biogrid_Adappi =0.5066
Sn_Biogrid_Adappi =0.6885
PPV_M_Biogrid_Adappi =0.3727
Acc_Biogrid_Adappi =0.2903
PPV_Biogrid_Adappi =0.1224


Precision_Collins_Adappi =0.7734
Recall_Collins_Adappi =0.6399
F1_Collins_Adappi =0.7003
Acc_M_Collins_Adappi =0.5474
Sn_Collins_Adappi =0.7873
PPV_M_Collins_Adappi =0.3806
Acc_Collins_Adappi =0.4582
PPV_Collins_Adappi =0.2666

Precision_Dip_Adappi =0.6019
Recall_Dip_Adappi =0.4727
F1_Dip_Adappi =0.5295
Acc_M_Dip_Adappi =0.5321
Sn_Dip_Adappi =0.5987
PPV_M_Dip_Adappi =0.4729
Acc_Dip_Adappi =0.3255
PPV_Dip_Adappi =0.1769

Precision_Krogan_core_Adappi =0.6918
Recall_Krogan_core_Adappi =0.6462
F1_Krogan_core_Adappi =0.6682
Acc_M_Krogan_core_Adappi =0.6303
Sn_Krogan_core_Adappi =0.7421
PPV_M_Krogan_core_Adappi =0.5354
Acc_Krogan_core_Adappi =0.4153
PPV_Krogan_core_Adappi =0.2325

Precision_Krogan14k_Adappi =0.5915
Recall_Krogan14k_Adappi =0.5328
F1_Krogan14k_Adappi =0.5606
Acc_M_Krogan14k_Adappi =0.5301
Sn_Krogan14k_Adappi =0.6821
PPV_M_Krogan14k_Adappi =0.4120
Acc_Krogan14k_Adappi =0.3566
PPV_Krogan14k_Adappi =0.1864

Precision_Biogrid_Clusterone =0.3601
Recall_Biogrid_Clusterone =0.4903
F1_Biogrid_Clusterone =0.4152
Acc_M_Biogrid_Clusterone =0.4731
Sn_Biogrid_Clusterone =0.4606
PPV_M_Biogrid_Clusterone =0.4859
Acc_Biogrid_Clusterone =0.3008
PPV_Biogrid_Clusterone =0.1964

Precision_Collins_Clusterone =0.5609
Recall_Collins_Clusterone =0.8006
F1_Collins_Clusterone =0.6596
Acc_M_Collins_Clusterone =0.6590
Sn_Collins_Clusterone =0.7841
PPV_M_Collins_Clusterone =0.5539
Acc_Collins_Clusterone =0.5238
PPV_Collins_Clusterone =0.3499

Precision_Dip_Clusterone =0.3584
Recall_Dip_Clusterone =0.3993
F1_Dip_Clusterone =0.3777
Acc_M_Dip_Clusterone =0.4346
Sn_Dip_Clusterone =0.3878
PPV_M_Dip_Clusterone =0.4870
Acc_Dip_Clusterone =0.3148
PPV_Dip_Clusterone =0.2555

Precision_Krogan_core_Clusterone =0.4246
Recall_Krogan_core_Clusterone =0.6215
F1_Krogan_core_Clusterone =0.5045
Acc_M_Krogan_core_Clusterone =0.5391
Sn_Krogan_core_Clusterone =0.5804
PPV_M_Krogan_core_Clusterone =0.5008
Acc_Krogan_core_Clusterone =0.4248
PPV_Krogan_core_Clusterone =0.3110

Precision_Krogan14k_Clusterone =0.3525
Recall_Krogan14k_Clusterone =0.4462
F1_Krogan14k_Clusterone =0.3938
Acc_M_Krogan14k_Clusterone =0.4897
Sn_Krogan14k_Clusterone =0.4983
PPV_M_Krogan14k_Clusterone =0.4812
Acc_Krogan14k_Clusterone =0.3523
PPV_Krogan14k_Clusterone =0.2490

Precision_Collins_Pc2p =0.3039
Recall_Collins_Pc2p =0.8392
F1_Collins_Pc2p =0.4462
Acc_M_Collins_Pc2p =0.6370
Sn_Collins_Pc2p =0.8776
PPV_M_Collins_Pc2p =0.4624
Acc_Collins_Pc2p =0.5534
PPV_Collins_Pc2p =0.3490

Precision_Dip_Pc2p =0.0891
Recall_Dip_Pc2p =0.5239
F1_Dip_Pc2p =0.1523
Acc_M_Dip_Pc2p =0.3529
Sn_Dip_Pc2p =0.4891
PPV_M_Dip_Pc2p =0.2547
Acc_Dip_Pc2p =0.3703
PPV_Dip_Pc2p =0.2804

Precision_Krogan_core_Pc2p =0.1226
Recall_Krogan_core_Pc2p =0.7846
F1_Krogan_core_Pc2p =0.2120
Acc_M_Krogan_core_Pc2p =0.4523
Sn_Krogan_core_Pc2p =0.7022
PPV_M_Krogan_core_Pc2p =0.2914
Acc_Krogan_core_Pc2p =0.4981
PPV_Krogan_core_Pc2p =0.3533

Precision_Krogan14k_Pc2p =0.0823
Recall_Krogan14k_Pc2p =0.6404
F1_Krogan14k_Pc2p =0.1459
Acc_M_Krogan14k_Pc2p =0.3793
Sn_Krogan14k_Pc2p =0.5841
PPV_M_Krogan14k_Pc2p =0.2463
Acc_Krogan14k_Pc2p =0.4364
PPV_Krogan14k_Pc2p =0.3261

x_simple = np.array([Acc_M_Biogrid_Adappi,Acc_M_Biogrid_Clusterone])
y_simple = np.array([F1_Biogrid_Adappi,F1_Biogrid_Clusterone])
my_rho = np.corrcoef(x_simple, y_simple)

print(my_rho)