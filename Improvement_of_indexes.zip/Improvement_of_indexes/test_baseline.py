from utils import *
from evaluation import *

if __name__ == '__main__':
    ######## 加载gt #######
    method = 'clusterone'
    dataname = 'krogan14k'
    current_path = os.getcwd()
    PPI_path = os.path.join(current_path, 'PPI_Dataset', dataname + '.txt')
    Protein_path = os.path.join(current_path, 'Feature_dataset', dataname, 'Residue_feature')
    
    # 读取PPI网络和金标准复合物
    PPI = pd.read_csv(PPI_path, sep='\t', header=None)
    gt = Load_txt_list('./PPI_Dataset/','golden_standard.txt')

    # 获取PPI网络中下载到的蛋白质
    protein_nodes = set(Get_protein_list(Protein_path))

    # 计算PPI网络蛋白质中可用的金标准复合物
    gt_in_PPI = []
    for complex in gt:
        protein_in_PPI = []
        for protein in complex:
            if protein in protein_nodes:
                protein_in_PPI.append(protein)
        if protein_in_PPI == complex:
            gt_in_PPI.append(complex)

    ####### 加载predict #######
    # 假设数据已经存储在文件中
    file_path = "Baseline/" +  method + "/" + dataname + ".txt"  # 替换为你的文件路径

    # 读取数据并按行处理
    with open(file_path, "r") as file:
        lines = file.readlines()

    # 用于存储合并并分割后的结果
    merged_lines = []
    previous_line = ""

    for line in lines:
        line = line.strip()  # 去除行首尾的空白字符
        if line:  # 仅处理非空行
            if line[0].isspace():  # 如果行首是空格，说明当前行应与上一行合并
                previous_line += " " + line.strip()  # 合并
            else:
                if previous_line:  # 如果上一行存在，先将上一行按空格分割后存入结果
                    merged_lines.append(previous_line.split())  # 按空格分割成子列表
                previous_line = line  # 更新为当前行

    # 处理最后一行，如果有内容，将其按空格分割后保存
    if previous_line:
        merged_lines.append(previous_line.split())  # 按空格分割成子列表

    # 打印结果，查看每一行作为一个子列表
    for merged_line in merged_lines:
        print(merged_line)
    predict_complex = merged_lines
    precision_temp, recall_temp, f1_temp, acc_temp, sn_temp, PPV_temp, score_temp = get_score(gt_in_PPI, predict_complex)
    print(score_temp)
